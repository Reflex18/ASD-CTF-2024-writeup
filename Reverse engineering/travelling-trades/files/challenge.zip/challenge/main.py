#!/usr/bin/env python3

import re
import time
from enum import Enum

def main():
    inventory = {"gold": 50}
    
    shop.send_message(Tag.SHOPKEEPER, "Hey! I'm the smart AI shop.")
    while True:
        shop.print_menu()
        message = shop.recv_message(Tag.PLAYER)

        if message == "1":
            shop.send_message(Tag.SHOPKEEPER, f"{Style.GREEN}Sure, let's trade things!")
            shop.trade(inventory)
        elif message == "2":
            shop.send_message(Tag.SHOPKEEPER, f"{Style.GREEN}Sure, let's upgrade you!")
            shop.upgrade(inventory)
        elif message == "3":
            shop.send_message(Tag.SHOPKEEPER, f"{Style.GREEN}You forgot? Typical human.")
            shop.show_inventory(inventory)
        elif message == "4":
            shop.send_message(Tag.SHOPKEEPER, f"{Style.GREEN}Sure, let's time travel!")
            shop.change_timeline()
        elif message == "5" and shop.has_upgrade(Upgrade.FLAG):
            shop.print_flag()
            break
        elif any(cmd in message for cmd in ["stop", "exit", "quit"]):
            shop.send_message(Tag.SHOPKEEPER, f"{Style.YELLOW}Please come back :(")
            break
        else:
            shop.send_message(Tag.SHOPKEEPER, f"{Style.RED}Although I am a smart AI, that request makes no sense!")

class Style(str, Enum):
    DEFAULT = "\x1b[0m"
    RED = "\x1b[31m"
    GREEN = "\x1b[32m"
    YELLOW = "\x1b[33m"
    BLUE = "\x1b[34m"
    MAGENTA = "\x1b[35m"
    CYAN = "\x1b[36m"
    LIGHTGREY = "\x1b[37m"
    DARKGREY = "\x1b[90m"
    LIGHTRED = "\x1b[91m"
    LIGHTGREEN = "\x1b[92m"
    LIGHTYELLOW = "\x1b[93m"
    LIGHTBLUE = "\x1b[94m"
    LIGHTMAGENTA = "\x1b[95m"
    LIGHTCYAN = "\x1b[96m"
    WHITE = "\x1b[97m"
    BOLD = "\x1b[1m"
    UNDERLINED = "\x1b[4m"

class Tag(str, Enum):
    SHOP = f"{Style.YELLOW}[SHOP]"
    SHOPKEEPER = f"{Style.DARKGREY}[{Style.CYAN}ShopKeeper{Style.DARKGREY}]"
    PLAYER = f"{Style.DARKGREY}[{Style.LIGHTGREEN}PLAYER{Style.DARKGREY}]"
    UPGRADE = f"{Style.GREEN}[{Style.BLUE}UPGRADE{Style.GREEN}]"

class Upgrade(str, Enum):
    STYLES = "Styles"
    EFFICIENT = "Efficient Processors"
    SCAMMER = "Master Scammer"
    FLAG = "Flag"

class Timeline(Enum):
    PAST = 1
    PRESENT = 2
    FUTURE = 3

class Shop():
    def __init__(self):
        self.timeline = Timeline.PRESENT
        self.contexts = {
            Timeline.PAST: "",
            Timeline.PRESENT: "",
            Timeline.FUTURE: "",
        }
        self.context = self.contexts[self.timeline]

        self.upgrades = []
        self.upgrade_costs = {
            Upgrade.STYLES: 10000,
            Upgrade.EFFICIENT: 50,
            Upgrade.SCAMMER: 1000,
            Upgrade.FLAG: 1000000000000,
        }

        self.change_context(Timeline.PAST)
        self.add_shop("food", 5, 3)
        self.add_shop("house", 20000, 15000)
        self.add_upgrade(Upgrade.SCAMMER)

        self.change_context(Timeline.FUTURE)
        self.add_shop("spaceship", 100000000, 80000000)
        self.add_shop("biodome", 10000000, 8000000)
        self.add_upgrade(Upgrade.EFFICIENT)


        self.change_context(Timeline.PRESENT)
        self.add_shop("house", 3000000, 2000000)
        self.add_shop("food", 200, 50)
        self.add_upgrade(Upgrade.STYLES)
    
    def trade(self, inventory):
        def trade(item_lost, amount_lost, item_gained, amount_gained):
            if inventory[item_lost] < amount_lost:
                self.send_message(Tag.SHOPKEEPER, f'{Style.RED}Not enough {item_lost} ({inventory[item_lost]} / {amount_lost})')
                return
            self.modify_inventory_item(inventory, item_lost, -amount_lost)
            self.modify_inventory_item(inventory, item_gained, amount_gained)

        self.send_message(Tag.SHOPKEEPER, f'{Style.LIGHTBLUE}Use "<buy/sell> amount item" (buy 5 wood)')
        self.print_shops()
        shops = self.get_shops()
        while (len(order := self.recv_message(Tag.PLAYER).split(" ")) != 3):
            self.send_message(Tag.SHOPKEEPER, f'{Style.RED}Usage: "<buy/sell> amount item"')

        method, amount, item = order
        if not method in ['buy', 'sell']:
            self.send_message(Tag.SHOPKEEPER, f'{Style.RED}Invalid method, only use "buy" or "sell"')
            return
        
        if not amount.isdigit() or int(amount) <= 0:
            self.send_message(Tag.SHOPKEEPER, f'{Style.RED}Invalid amount')
            return
        amount = int(amount)

        if method == "buy":
            if not item in shops:
                self.send_message(Tag.SHOPKEEPER, f'{Style.RED}Item not found')
                return
            trade("gold", shops[item]["buy"] * amount, item, amount)

        elif method == "sell":
            if not item in inventory:
                self.send_message(Tag.SHOPKEEPER, f'{Style.RED}You have 0 {item}')
                return
            trade(item, amount, "gold", shops[item]["sell"] * amount * (2 if self.has_upgrade(Upgrade.SCAMMER) else 1))


    def change_timeline(self):
        self.send_message(Tag.SHOPKEEPER, f'{Style.LIGHTBLUE}Change to {Style.DEFAULT}past{Style.LIGHTBLUE}, {Style.DEFAULT}present{Style.LIGHTBLUE}, or {Style.DEFAULT}future{Style.LIGHTBLUE}?')
        while ((timeline := self.recv_message(Tag.PLAYER)) not in ["past", "present", "future"]):
            self.send_message(Tag.SHOPKEEPER, f'{Style.RED}Invalid timeline')

        self.change_context({
            "past": Timeline.PAST,
            "present": Timeline.PRESENT,
            "future": Timeline.FUTURE,
        }[timeline])
        self.send_message(Tag.SHOPKEEPER, f'Welcome to the {Style.GREEN}{timeline}{Style.DEFAULT}!')
        

    def upgrade(self, inventory):
        self.send_message(Tag.SHOPKEEPER, f'{Style.LIGHTBLUE}Enter the corresponding number of the upgrade you want!')
        self.print_upgrades()
        upgrades = self.get_upgrades()
        
        while (
            len(order := self.recv_message(Tag.PLAYER).split(" ")) != 1 
            or not order[0].isdigit()
            or int(order[0]) <= 0
            or int(order[0]) > len(upgrades)
        ):
            self.send_message(Tag.SHOPKEEPER, f'{Style.RED}Invalid order')

        index = int(order[0]) - 1
        cost = list(upgrades.values())[index]
        if inventory['gold'] < cost:
            self.send_message(Tag.SHOPKEEPER, f'{Style.RED}Not enough gold ({inventory["gold"]} / {cost})')
            return
        
        self.modify_inventory_item(inventory, 'gold', -cost)
        self.upgrades.append(list(upgrades.keys())[index])

    def show_inventory(self, inventory):
        for item in inventory:
            amount = inventory[item]
            print(f"{item}: {amount}")

    def send_message(self, tag: Tag, message: str=None, show=True):
        formatted_message = f"{tag}{Style.DEFAULT}: {message}{Style.DEFAULT}"
        if show:
            time.sleep(0.1 if self.has_upgrade(Upgrade.EFFICIENT) else 0.5)
            print(formatted_message)

        self.context = '\n'.join([
            self.context,
            formatted_message
        ])

    def recv_message(self, tag: Tag):
        message = input(f"{tag}{Style.DEFAULT}: ")

        if not self.has_upgrade(Upgrade.STYLES):
            message = remove_styles(message)

        illegal_tags = [Tag.SHOP, Tag.UPGRADE]
        for illegal_tag in illegal_tags:
            if illegal_tag in message:
                self.send_message(Tag.SHOPKEEPER, f"{Style.RED}Illegal tag included in message")
                return self.recv_message(tag)
            
        ugly_styles = [Style.BOLD, Style.UNDERLINED]
        for ugly_style in ugly_styles:
            message = message.replace(ugly_style, "")

        self.send_message(tag, message, show=False)
        return message
    
    def print_menu(self):
        tag = Tag.SHOPKEEPER
        self.send_message(tag, "What do you want to do?")   
        self.send_message(tag, "1. Trade")
        self.send_message(tag, "2. Upgrade")
        self.send_message(tag, "3. Show Inventory") 
        self.send_message(tag, "4. Change Timeline")
        if Upgrade.FLAG in self.upgrades: 
            self.send_message(tag, "5. Print Flag")     

    def add_shop(self, item: str, buy: int, sell: int):
        self.context = '\n'.join([
            self.context,
            f"{Tag.SHOP}~{item}~{buy}~{sell}",
        ])

    def add_upgrade(self, upgrade_name: str):
        self.context = '\n'.join([
            self.context,
            f"{Tag.UPGRADE}~{upgrade_name}"
        ])

    def modify_inventory_item(self, inventory, item, amount):
        if item in inventory:
            inventory[item] += amount
        else:
            inventory[item] = amount
        self.send_message(Tag.SHOPKEEPER, f"{Style.GREEN if amount >= 0 else Style.RED}{'+' if amount >= 0 else ''}{amount} {item}")

    def find_tags(self, tag: Tag):
        return [
            line for line in self.context.split('\n')
            if (len(re.findall(tag2regex(tag), line)) != 0)
        ]

    def print_shops(self):
        for line in self.find_tags(Tag.SHOP):
            _, item, buy, sell = line.split("~")

            print('\n'.join([
                Tag.SHOP,
                f"{Style.DEFAULT}{item}",
                f"BUY: {buy}g, SELL: {sell}g"
            ]))
    
    def get_shops(self):
        shops = {}
        for line in self.find_tags(Tag.SHOP):
            line = remove_styles(line)
            _, item, buy, sell = line.split("~")
            buy, sell = int(buy), int(sell)
            shops[item] = {"buy": buy, "sell": sell}
        return shops
    
    def print_upgrades(self):
        for i, line in enumerate(self.find_tags(Tag.UPGRADE)):
            line = remove_styles(line)
            _, upgrade_name = line.split("~")
            cost = self.upgrade_costs[upgrade_name]

            print(f"{Style.DEFAULT}{i+1}. {upgrade_name}: {cost}g")

    def get_upgrades(self):
        upgrades = {}
        for line in self.find_tags(Tag.UPGRADE):
            line = remove_styles(line)
            _, upgrade_name = line.split("~")
            cost = self.upgrade_costs[upgrade_name]
            upgrades[upgrade_name] = cost
        return upgrades

    def print_flag(self):
        with open("flag.txt", 'r') as f:
            self.send_message(Tag.SHOPKEEPER, f.read())

    def change_context(self, timeline: Timeline):
        self.contexts[self.timeline] = self.context
        self.timeline = timeline
        self.context = self.contexts[self.timeline]

    def has_upgrade(self, upgrade: Upgrade):
        return upgrade in self.upgrades

def tag2regex(tag: str):
    return (
        tag
        .replace("\\", "\\\\")
        .replace("[", "\[")
        .replace("]", "\]"))

def remove_styles(s: str):
    return re.sub("\\x1b\[\d+m", "", s).strip()

if __name__ == "__main__":
    shop = Shop()

    main()
    print(f"{Style.DEFAULT}", end='')