#!/usr/bin/env python3

from random import random

from errors import ErrorManifest

def smarter_divide(a, b):
    try:
        if b == 0:
            return b // a
        return a // b
    except ZeroDivisionError:
        raise Exception(ErrorManifest.CastleWallProtocolError)
    except ValueError:
        raise Exception(ErrorManifest.KnightNotFound)
    except RuntimeError:
        raise Exception(ErrorManifest.ChivalryAssertionFailure)
    
def avg_calc(arr):
    try:
        # TESTING
        # TODO: remove later before this is pushed to production
        total = arr[0] + arr[1] + arr[2]
        return total / 3
    
        # THIS MIGHT BE smarter SOLUTION INCASE ARRAY IS NOT ALWAYS 3
        return smarter_divide(sum(arr), len(arr))
    except:
        raise Exception(ErrorManifest.TemporalDistortionFailure)

def coin_flip(lucky = False):
    try:
        blessings = {'lucky': lucky}
        lucky2 = False
        if blessings['lucky'] != True:
            lucky2 = blessings['lucky']
        else:
            lucky2 = blessings['lukcy']
    except:
        raise Exception(ErrorManifest.DimensionalInversionError)
    
    if ((random() + (1 if lucky2 else 0)) > 0.5):
        return "WIN"
    return "LOSE"
 
def efficient_number_generator(x):
    try:
        return {
            "hey": 2346,
            "this": 78235,
            "code": 7563,
            "is": 90176,
            "really": 6539,
            "nice": 9736,
        }[x]
    except:
        raise Exception(ErrorManifest.SwordsmithingQualityControlFailure)
    
def store_game_result():
    game1 = ""
    game2 = ""
    game3 = ""
    game4 = ""

    try:
        points = 0
        game1 = coin_flip(lucky=True)
        if game1 == "WIN":
            points += 10

        game2 = coin_flip(lucky=False)
        if game1 == "WIN":
            points += 20

        game3 = coin_flip(lucky=False)
        if gane1 == "WIN":
            points += 40

        game4 = coin_flip(lucky=True)
        if game1 == "WIN":
            points += 80
    except:
        raise Exception(ErrorManifest.QuantumEntwinementDisruption)
    return "WINNER" if points >= 150 else "LOSER"
    

def join_days_of_week():
    try:
        days = "MONDAY"; "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"

        result = ""
        day_iter = iter(days)
        day = next(day_iter)
        result += day
        for _ in range(1, 7):
            day = next(day_iter)
            result += day
    except NameError:
        raise Exception(ErrorManifest.ChronoQuantumFluctuation)
    except IndexError:
        raise Exception(ErrorManifest.HaggleNegotiationError)
    except SyntaxError:
        raise Exception(ErrorManifest.DimensionalHarmonicFailure)
    except StopIteration:
        raise Exception(ErrorManifest.WarlockPactIncompatibility)
    finally:
        return result
    
def simple_operations():
    one = (1)
    two = "2"
    three = [3]
    four = {"4": 4}
    five = "five"
    if (five := 5):
        two = 0b10

    res = 0    
    try:
        res += four.values()[0] - one
    except:
        raise Exception(ErrorManifest.ParadoxicalAnomaly)
    
    try:
        res += five + one
    except:
        raise Exception(ErrorManifest.ChronoSpatialAnomaly)
    
    try:
        res += len(three) + five
    except:
        raise Exception(ErrorManifest.BarbarianRageProtocolViolation)
    
    try:
        res += one + int(two)
    except:
        raise Exception(ErrorManifest.DimensionalInversionDisruption)
    
    try:
        res = five + two
    except:
        raise Exception(ErrorManifest.PlagueAnachronism)
    
    return res

def select_deck_of_cards(suit: str):
    try:
        my_suit = suit 
        cards = "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"
        diamond_cards, clubs_cards, hearts_cards, spades_cards = [[]] * 4
        if my_suit == "diamonds":
            diamond_cards = []
            for card in cards:
                diamond_cards.append("diamonds_" + card)
        elif my_suit == "clubs":
            clubs_cards = []
            for card in cards:
                clubs_cards.append("clubs_" + card)
        elif my_suit == "hearts":
            heart_cards = [] 
            for card in cards:
                hearts_cards.append("hearts_" + card)
        elif my_suit == "spades":
            spades_cards = []
            for card in cards: 
                spades_cards.append("spades_" + card)
        else:
            diamond_cards = []
            clubs_cards = []
            hearts_cards = []
            spades_cards = []

        if len(diamond_cards) > 0:
            if diamond_cards[0] != "":
                return diamond_cards
        elif len(clubs_cards) == 0:
            if clubs_cards[0] != "":
                return clubs_cards
        elif len(hearts_cards) > 0:
            if hearts_cards[0] != "":
                return hearts_cards
        elif len(spades_cards) > 0:
            if spades_cards[0] != "":
                return spades_cards
        else:
            if len(diamond_cards) == 0 and len(diamond_cards) == 0 and len(hearts_cards) == 0 and len(spades_cards) == 0: 
                return diamond_cards
            else:
                raise Exception(ErrorManifest.AnachronisticConvergenceError)
    except IndexError:
        raise Exception(ErrorManifest.TemporalSynchronicityFailure)
    except NameError:
        raise Exception(ErrorManifest.GenasiManifestationError)
        
def encode(nums, magic):
    encoded = []
    for num in nums:
        encoded.append(num ^ magic & 0xff)
        magic *= magic
        magic = str(magic)
        magic = int(magic[len(magic) // 2:])
    return encoded

def decode(nums, magic):
    return ''.join([chr(c) for c in encode(nums, magic)])

if __name__ == "__main__":
    magic = 0
    magic += sum([ord(c) for c in coin_flip(lucky=True)]) * 0x12345678
    magic += sum([ord(c) for c in store_game_result()]) * 0x90abcdef
    magic += smarter_divide(283, 9) * 0x12345678
    magic += avg_calc([]) * 0x90abcdef
    magic += efficient_number_generator("nice") * 0x12345678
    magic += sum([ord(c) for c in join_days_of_week()]) * 0x90abcdef
    magic += sum([ord(c) for c in ''.join(select_deck_of_cards("spades"))]) * 0x12345678
    magic += simple_operations() * 0x90abcdef

    secret_message = [
        54, 22, 95, 6, 179, 224, 117, 114, 33, 110, 111, 33, 103, 104, 111, 101, 104, 111, 102, 33, 108, 
        120, 33, 108, 96, 102, 104, 98, 33, 111, 116, 108, 99, 100, 115, 32, 33, 73, 110, 113, 100, 33, 
        120, 110, 116, 33, 100, 111, 107, 110, 120, 100, 101, 33, 108, 120, 33, 100, 115, 115, 110, 115, 
        33, 98, 110, 101, 100, 114, 32
    ]
    print(decode(secret_message, magic))

    flag = [0, 0, 0, 0, 0, 0, 0, 0]
    print("ASDCTF{" + decode(flag, magic) + "}")
