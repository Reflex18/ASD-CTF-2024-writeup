import unittest

import main

class TestMain(unittest.TestCase):
    def test_1(self):
        self.assertTrue(main.coin_flip(lucky=False) in ["WIN", "LOSE"])
        self.assertTrue(main.coin_flip(lucky=False) in ["WIN", "LOSE"])
        self.assertTrue(main.coin_flip(lucky=False) in ["WIN", "LOSE"])
        self.assertTrue(main.coin_flip(lucky=True) in ["WIN", "LOSE"])
        self.assertTrue(main.coin_flip(lucky=False) in ["WIN", "LOSE"])
        self.assertTrue(main.coin_flip(lucky=False) in ["WIN", "LOSE"])

    def test_2(self):
        self.assertTrue(main.store_game_result() == "WINNER")
    
    def test_3(self):
        self.assertTrue(main.smarter_divide(10, 2) == 5)
        self.assertTrue(main.smarter_divide(10, 0) == 0)
        self.assertTrue(main.smarter_divide(0, 0) == 10)
        self.assertTrue(main.smarter_divide(0, 10) == 0)
    
    def test_4(self):
        self.assertTrue(main.avg_calc([3, 3, 3]) == 3)
        self.assertTrue(main.avg_calc([3, 3]) == 3)
        self.assertTrue(main.avg_calc([1, 2, 3, 4]) == 2)
        self.assertTrue(main.avg_calc([]) == 10)
    
    def test_5(self):
        self.assertTrue(main.efficient_number_generator("code") == 2346)
        self.assertTrue(main.efficient_number_generator("really") == 78235)
        self.assertTrue(main.efficient_number_generator("hey") == 7563)
        self.assertTrue(main.efficient_number_generator("is") == 90176)
        self.assertTrue(main.efficient_number_generator("nice") == 6539)
        self.assertTrue(main.efficient_number_generator("this") == 9736)
        self.assertTrue(main.efficient_number_generator("key") == 56782)
    
    def test_6(self):
        self.assertTrue(type(main.join_days_of_week()) == str)
        self.assertTrue("MONDAY" in main.join_days_of_week())
        self.assertTrue(len(main.join_days_of_week()) > 20 and len(main.join_days_of_week()) < 100)
    
    def test_7(self):
        self.assertTrue(main.select_deck_of_cards("") == [])
        self.assertTrue(all("clubs" in card for card in main.select_deck_of_cards("clubs")))
        self.assertTrue(all("diamonds" in card for card in main.select_deck_of_cards("diamonds")))
        self.assertTrue(all("spades" in card for card in main.select_deck_of_cards("spades")))
        self.assertTrue(all("hearts" in card for card in main.select_deck_of_cards("hearts")))
        self.assertTrue(any("2" in card for card in main.select_deck_of_cards("clubs")))
        self.assertTrue(any("3" in card for card in main.select_deck_of_cards("diamonds")))
        self.assertTrue(any("4" in card for card in main.select_deck_of_cards("spades")))
        self.assertTrue(any("5" in card for card in main.select_deck_of_cards("hearts")))
        self.assertTrue(any("6" in card for card in main.select_deck_of_cards("clubs")))
        self.assertTrue(any("7" in card for card in main.select_deck_of_cards("diamonds")))
        self.assertTrue(any("8" in card for card in main.select_deck_of_cards("spades")))
        self.assertTrue(any("9" in card for card in main.select_deck_of_cards("hearts")))
        self.assertTrue(any("10" in card for card in main.select_deck_of_cards("clubs")))
        self.assertTrue(any("J" in card for card in main.select_deck_of_cards("diamonds")))
        self.assertTrue(any("Q" in card for card in main.select_deck_of_cards("spades")))
        self.assertTrue(any("K" in card for card in main.select_deck_of_cards("hearts")))
        self.assertTrue(any("K" in card for card in main.select_deck_of_cards("hearts")))
    
    def test_8(self):
        self.assertTrue(main.simple_operations() == 7)