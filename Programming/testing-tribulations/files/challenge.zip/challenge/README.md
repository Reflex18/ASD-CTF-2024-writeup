# Testing Tribulations

## Run tests
`python3 -m unittest -f test.py`